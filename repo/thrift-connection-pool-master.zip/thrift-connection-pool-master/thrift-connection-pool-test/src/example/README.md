## thrift demo

start the server

	python py-server.py


