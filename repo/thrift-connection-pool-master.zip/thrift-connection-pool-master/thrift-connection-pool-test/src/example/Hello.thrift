namespace py hello
namespace go hello

service Hello{ 
	string helloString(1:string para) 
} 
