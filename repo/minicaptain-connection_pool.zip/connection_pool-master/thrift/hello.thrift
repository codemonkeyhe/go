namespace go hello

service RpcService {
    void helloWorld(1:string name)
}
