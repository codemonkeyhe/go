# connpool
connection pool for go/golang to connect with redis/kafka/hbase/mysql and anything else  
It has been stable for running over 1 year in the production environment of our company.  
it has deal with over 1 billion messages every day with kafka and hbase.  
so you can ease to use it.
